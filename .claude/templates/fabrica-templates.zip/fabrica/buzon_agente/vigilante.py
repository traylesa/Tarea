#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Vigilante de Buzones v2.3.1 - Modelo Expedientes con Playbook Operacional
Automatiza la creación de expedientes desde archivos depositados en entrada/

Características v2.3.1:
- Clasificación inteligente por contenido (categoria, severidad, impacto, urgencia, complejidad)
- Decisión de camino estratégico: TICKET_RAPIDO | MINI_PROYECTO | PROYECTO_COMPLETO
- Generación de 10 plantillas de fases (00-09) según camino
- DICCIONARIO DE DOMINIO centralizado en docs/ (coordinado con CLAUDE.md)
- PROPUESTA_DICCIONARIO.md por expediente (para cambios al diccionario central)
- ESTADO.json para tracking
- INSTRUCCIONES_AGENTE.md como playbook operacional completo
- Lanzamiento automático de Claude con prompt detallado
- Logging detallado

Uso:
    python vigilante_v2.3.1.py --modo batch     # Procesar una vez
    python vigilante_v2.3.1.py --modo watch     # Monitoreo continuo
"""

import os
import sys
import time
import shutil
import json
import argparse
import re
import subprocess
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Tuple

# Intentar importar watchdog (solo necesario en modo watch)
try:
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler
    WATCHDOG_AVAILABLE = True
except ImportError:
    WATCHDOG_AVAILABLE = False

# ==============================================================================
# CONFIGURACIÓN
# ==============================================================================

RAIZ = Path(__file__).parent.parent.parent
DIR_BUZONES = RAIZ / "fabrica" / "buzon_agente"
DIR_ENTRADA = DIR_BUZONES / "entrada"
DIR_TALLER = DIR_BUZONES / "taller_activo"
DIR_ARCHIVO = DIR_BUZONES / "archivo_concluido"
DIR_DOCS = RAIZ / "docs"  # ⭐ Directorio para diccionario central
CONFIG_FILE = DIR_BUZONES / "buzones.json"
LOG_FILE = DIR_BUZONES / "vigilante.log"

# ==============================================================================
# SISTEMA DE LOGGING
# ==============================================================================

class Logger:
    """Logger simple con output a archivo y consola con colores"""

    def __init__(self, log_file: Path):
        self.log_file = log_file
        self.log_file.parent.mkdir(parents=True, exist_ok=True)

    def _log(self, nivel: str, mensaje: str, color: str = ""):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        linea = f"[{timestamp}] {nivel}: {mensaje}"

        # Escribir a archivo
        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(linea + "\n")

        # Mostrar en consola con color
        if color:
            print(f"{color}{linea}\033[0m")
        else:
            print(linea)

    def info(self, mensaje: str):
        self._log("INFO", mensaje)

    def warning(self, mensaje: str):
        self._log("WARNING", mensaje, "\033[93m")  # Amarillo

    def error(self, mensaje: str):
        self._log("ERROR", mensaje, "\033[91m")  # Rojo

    def success(self, mensaje: str):
        self._log("OK", mensaje, "\033[92m")  # Verde

# Instancia global del logger
logger = Logger(LOG_FILE)

# ==============================================================================
# GESTOR DE CONFIGURACIÓN
# ==============================================================================

class ConfiguracionBuzones:
    """Gestor de configuración de buzones"""

    DEFAULT_CONFIG = {
        "version": "2.3.1",
        "creado_en": datetime.now().isoformat(),
        "modelo": "expedientes_playbook_operacional",
        "rutas": {
            "entrada": "fabrica/buzon_agente/entrada/",
            "taller_activo": "fabrica/buzon_agente/taller_activo/",
            "archivo_concluido": "fabrica/buzon_agente/archivo_concluido/"
        },
        "deteccion_tipo": {
            ".md": {"tipo": "especificacion", "accion": "/implanta"},
            ".txt": {"tipo": "especificacion", "accion": "/implanta"},
            ".log": {"tipo": "error", "accion": "/corrige"},
            ".email": {"tipo": "feedback", "accion": "Transformar a especificacion"}
        },
        "clasificacion_inteligente": {
            "habilitado": True,
            "max_lineas_preview": 120,
            "keywords": {
                "urgente": ["urgente", "inmediato", "critical", "blocker"],
                "bug": ["bug", "error", "falla", "defecto", "issue"],
                "feature": ["feature", "funcionalidad", "implementar", "añadir"],
                "refactor": ["refactor", "mejorar", "optimizar", "reorganizar"]
            }
        },
        "generacion_fases": {
            "habilitado": True,
            "fases_disponibles": [
                "00_ESTRATEGIA", "01_ANALISIS", "02_INVESTIGACION", "03_PLAN",
                "04_DISENO", "05_RESULTADO", "06_VALIDACION", "07_DESPLIEGUE",
                "08_OPERACION", "09_EVOLUCION"
            ]
        },
        "diccionario_dominio": {
            "habilitado": True,
            "ubicacion": "docs/DICCIONARIO_DOMINIO.md",  # ⭐ Central en docs/
            "propuesta_por_expediente": True
        },
        "lanzamiento_automatico": {
            "habilitado": True,
            "comando": "claude",
            "opciones": "--dangerously-skip-permissions"
        },
        "vigilante": {
            "habilitado": True,
            "patrones_ignorar": [
                "*.tmp",
                "*.processing",
                ".DS_Store",
                "INSTRUCCIONES_AGENTE.md",
                "LEEME.md",
                "PROPUESTA_DICCIONARIO.md"
            ],
            "archivo_log": "fabrica/buzon_agente/vigilante.log"
        }
    }

    def __init__(self, config_file: Path):
        self.config_file = config_file
        self.config = self._cargar_config()

    def _cargar_config(self) -> dict:
        """Carga configuración desde archivo, o crea default"""
        if self.config_file.exists():
            try:
                with open(self.config_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                logger.warning(f"Error al cargar config, usando default: {e}")
                return self.DEFAULT_CONFIG
        else:
            # Crear config default
            self._guardar_config(self.DEFAULT_CONFIG)
            return self.DEFAULT_CONFIG

    def _guardar_config(self, config: dict):
        """Guarda configuración a archivo"""
        try:
            self.config_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Error al guardar config: {e}")

    def get(self, clave: str, default=None):
        """Obtiene valor de configuración con soporte para claves anidadas"""
        partes = clave.split(".")
        valor = self.config
        for parte in partes:
            if isinstance(valor, dict):
                valor = valor.get(parte, {})
            else:
                return default
        return valor if valor != {} else default

    def debe_ignorar(self, nombre_archivo: str) -> bool:
        """Verifica si un archivo debe ser ignorado"""
        patrones = self.config.get("vigilante", {}).get("patrones_ignorar", [])

        for patron in patrones:
            if patron.startswith("*"):
                extension = patron[1:]
                if nombre_archivo.endswith(extension):
                    return True
            elif nombre_archivo == patron:
                return True

        return False

    def obtener_tipo_archivo(self, extension: str) -> Dict[str, str]:
        """Obtiene tipo y acción para una extensión"""
        deteccion = self.config.get("deteccion_tipo", {})
        return deteccion.get(extension, {
            "tipo": "desconocido",
            "accion": "Revisar manualmente"
        })

# ==============================================================================
# CLASIFICADOR INTELIGENTE
# ==============================================================================

class ClasificadorInteligente:
    """Clasifica contenido por categoría, severidad, impacto, urgencia y complejidad"""

    def __init__(self, config: ConfiguracionBuzones):
        self.config = config
        self.habilitado = config.get("clasificacion_inteligente.habilitado", True)
        self.max_lineas = config.get("clasificacion_inteligente.max_lineas_preview", 120)

    def clasificar(self, contenido: str, extension: str) -> Dict:
        """Clasifica contenido y retorna metadatos"""

        if not self.habilitado:
            return self._clasificacion_default()

        # Analizar primeras líneas
        lineas = contenido.split("\n")[:self.max_lineas]
        texto = "\n".join(lineas).lower()

        # Detectar categoria
        categoria = self._detectar_categoria(texto)

        # Detectar severidad
        severidad = self._detectar_severidad(texto)

        # Detectar impacto
        impacto = self._detectar_impacto(texto, extension)

        # Detectar urgencia
        urgencia = self._detectar_urgencia(texto)

        # Detectar complejidad
        complejidad = self._detectar_complejidad(texto, lineas)

        return {
            "categoria": categoria,
            "severidad": severidad,
            "impacto": impacto,
            "urgencia": urgencia,
            "complejidad": complejidad
        }

    def _clasificacion_default(self) -> Dict:
        """Clasificación por defecto cuando está deshabilitado"""
        return {
            "categoria": "PROYECTO",
            "severidad": "MEDIA",
            "impacto": "MEDIO",
            "urgencia": "NORMAL",
            "complejidad": "STANDARD"
        }

    def _detectar_categoria(self, texto: str) -> str:
        """Detecta categoría: BUG | FEATURE | REFACTOR | PROYECTO"""
        if any(kw in texto for kw in ["bug", "error", "falla", "defecto", "issue", "crítico"]):
            return "BUG"
        elif any(kw in texto for kw in ["feature", "funcionalidad", "añadir", "agregar", "nueva"]):
            return "FEATURE"
        elif any(kw in texto for kw in ["refactor", "mejorar", "optimizar", "reorganizar", "limpiar"]):
            return "REFACTOR"
        else:
            return "PROYECTO"

    def _detectar_severidad(self, texto: str) -> str:
        """Detecta severidad: CRITICA | ALTA | MEDIA | BAJA"""
        if any(kw in texto for kw in ["crítico", "blocker", "severo", "grave", "production"]):
            return "CRITICA"
        elif any(kw in texto for kw in ["urgente", "importante", "prioridad alta", "high"]):
            return "ALTA"
        elif any(kw in texto for kw in ["menor", "trivial", "low", "baja prioridad"]):
            return "BAJA"
        else:
            return "MEDIA"

    def _detectar_impacto(self, texto: str, extension: str) -> str:
        """Detecta impacto: ALTO | MEDIO | BAJO"""
        # Archivos .log suelen ser impacto alto (errores en producción)
        if extension == ".log":
            return "ALTO"

        if any(kw in texto for kw in ["sistema completo", "toda la aplicación", "todos los usuarios"]):
            return "ALTO"
        elif any(kw in texto for kw in ["módulo específico", "algunos usuarios", "componente"]):
            return "MEDIO"
        else:
            return "BAJO"

    def _detectar_urgencia(self, texto: str) -> str:
        """Detecta urgencia: INMEDIATA | ALTA | NORMAL | BAJA"""
        if any(kw in texto for kw in ["inmediato", "ahora", "urgente", "hoy mismo"]):
            return "INMEDIATA"
        elif any(kw in texto for kw in ["esta semana", "pronto", "próximamente"]):
            return "ALTA"
        elif any(kw in texto for kw in ["futuro", "cuando sea posible", "backlog"]):
            return "BAJA"
        else:
            return "NORMAL"

    def _detectar_complejidad(self, texto: str, lineas: List[str]) -> str:
        """Detecta complejidad: MINI | STANDARD | EPIC"""
        # Heurística: longitud del texto + keywords
        num_lineas = len([l for l in lineas if l.strip()])

        if num_lineas < 10:
            return "MINI"
        elif num_lineas > 50 or any(kw in texto for kw in ["arquitectura", "múltiples módulos", "integración completa"]):
            return "EPIC"
        else:
            return "STANDARD"

# ==============================================================================
# DECISOR DE CAMINO ESTRATÉGICO
# ==============================================================================

class DecisorCamino:
    """Decide camino estratégico según clasificación"""

    CAMINOS = {
        "TICKET_RAPIDO": {
            "descripcion": "Tickets rápidos (bugs menores, fixes simples)",
            "fases": ["00_ESTRATEGIA", "03_PLAN", "05_RESULTADO", "06_VALIDACION"]
        },
        "MINI_PROYECTO": {
            "descripcion": "Proyectos pequeños (features simples, refactors)",
            "fases": ["00_ESTRATEGIA", "01_ANALISIS", "03_PLAN", "04_DISENO",
                     "05_RESULTADO", "06_VALIDACION", "07_DESPLIEGUE", "08_OPERACION"]
        },
        "PROYECTO_COMPLETO": {
            "descripcion": "Proyectos complejos (arquitectura, integraciones)",
            "fases": ["00_ESTRATEGIA", "01_ANALISIS", "02_INVESTIGACION", "03_PLAN",
                     "04_DISENO", "05_RESULTADO", "06_VALIDACION", "07_DESPLIEGUE",
                     "08_OPERACION", "09_EVOLUCION"]
        }
    }

    def decidir(self, clasificacion: Dict) -> Tuple[str, str]:
        """Decide camino y retorna (camino, justificacion)"""

        complejidad = clasificacion.get("complejidad", "STANDARD")
        categoria = clasificacion.get("categoria", "PROYECTO")
        severidad = clasificacion.get("severidad", "MEDIA")

        # TICKET_RAPIDO: bugs críticos simples o fixes urgentes
        if categoria == "BUG" and complejidad == "MINI":
            return ("TICKET_RAPIDO",
                    "Bug simple que requiere fix rápido sin análisis extenso")

        # PROYECTO_COMPLETO: complejidad EPIC o proyectos de arquitectura
        if complejidad == "EPIC" or categoria == "PROYECTO":
            return ("PROYECTO_COMPLETO",
                    "Proyecto complejo que requiere análisis profundo y todas las fases")

        # MINI_PROYECTO: resto de casos (features, refactors medianos)
        return ("MINI_PROYECTO",
                "Feature o refactor de complejidad media con fases estándar")

    def obtener_fases(self, camino: str) -> List[str]:
        """Obtiene lista de fases para un camino"""
        return self.CAMINOS.get(camino, {}).get("fases", [])

# ==============================================================================
# GENERADOR DE PLANTILLAS DE FASES
# ==============================================================================

class GeneradorFases:
    """Genera archivos de plantillas para cada fase"""

    PLANTILLAS = {
        "00_ESTRATEGIA": """# 00 - ESTRATEGIA

**Fase:** Definición Estratégica
**Expediente:** {expediente}
**Camino:** {camino}

---

## 🎯 OBJETIVO

Definir la estrategia general del expediente: qué se quiere lograr, por qué es importante, y cuál es el enfoque de alto nivel.

---

## 📥 ENTRADAS

- Archivo principal del expediente: `{archivo_principal}`
- Clasificación automática:
  - Categoría: {categoria}
  - Severidad: {severidad}
  - Urgencia: {urgencia}

---

## 📤 SALIDAS

- [ ] Objetivo claro del expediente
- [ ] Criterios de éxito definidos
- [ ] Restricciones identificadas
- [ ] Riesgos principales listados

---

## ✅ CHECKLIST

- [ ] Objetivo documentado (qué y por qué)
- [ ] Alcance definido (qué SÍ y qué NO)
- [ ] Stakeholders identificados
- [ ] Restricciones técnicas/negocio claras
- [ ] Riesgos principales evaluados

---

## 📝 CONTENIDO

### Objetivo
[Qué se quiere lograr]

### Criterios de Éxito
1. [Criterio 1]
2. [Criterio 2]

### Restricciones
- [Restricción 1]
- [Restricción 2]

### Riesgos
- [Riesgo 1 + mitigación]
- [Riesgo 2 + mitigación]

---

**Estado:** {estado_fase}
""",

        "01_ANALISIS": """# 01 - ANÁLISIS

**Fase:** Análisis Detallado
**Expediente:** {expediente}
**Camino:** {camino}

---

## 🎯 OBJETIVO

Analizar el problema/requerimiento en profundidad para entender todos los aspectos técnicos y de negocio.

---

## 📥 ENTRADAS

- 00_ESTRATEGIA.md (objetivo y alcance)
- Archivo principal: `{archivo_principal}`
- Código existente relacionado (si aplica)

---

## 📤 SALIDAS

- [ ] Análisis de situación actual (AS-IS)
- [ ] Análisis de situación deseada (TO-BE)
- [ ] GAP analysis completo
- [ ] Componentes afectados identificados

---

## ✅ CHECKLIST

- [ ] Situación actual documentada
- [ ] Requisitos funcionales listados
- [ ] Requisitos no funcionales listados
- [ ] Componentes afectados identificados
- [ ] Dependencies mapeadas

---

## 📝 CONTENIDO

### Situación Actual (AS-IS)
[Cómo funciona ahora]

### Situación Deseada (TO-BE)
[Cómo debería funcionar]

### Requisitos Funcionales
1. [RF-1]
2. [RF-2]

### Requisitos No Funcionales
- Performance: [especificar]
- Seguridad: [especificar]
- Escalabilidad: [especificar]

### Componentes Afectados
- [Componente 1]
- [Componente 2]

---

**Estado:** {estado_fase}
""",

        "02_INVESTIGACION": """# 02 - INVESTIGACIÓN

**Fase:** Investigación de Opciones
**Expediente:** {expediente}
**Camino:** {camino}

---

## 🎯 OBJETIVO

Investigar opciones técnicas, patrones, librerías y enfoques alternativos para implementar la solución.

---

## 📥 ENTRADAS

- 01_ANALISIS.md (requisitos completos)
- Arquitectura actual del sistema

---

## 📤 SALIDAS

- [ ] Opciones técnicas evaluadas
- [ ] Comparativa de alternativas
- [ ] Recomendación fundamentada
- [ ] Decisión arquitectónica documentada (ADR)

---

## ✅ CHECKLIST

- [ ] Al menos 3 opciones investigadas
- [ ] Pros/cons de cada opción listados
- [ ] Criterios de decisión definidos
- [ ] Opción recomendada justificada
- [ ] ADR creado (si aplica)

---

## 📝 CONTENIDO

### Opciones Investigadas

#### Opción 1: [Nombre]
- **Descripción:** [Qué es]
- **Pros:** [Ventajas]
- **Cons:** [Desventajas]
- **Complejidad:** [Alta/Media/Baja]

#### Opción 2: [Nombre]
[Similar estructura]

### Criterios de Decisión
1. [Criterio 1 con peso]
2. [Criterio 2 con peso]

### Recomendación
**Opción seleccionada:** [X]
**Justificación:** [Por qué]

---

**Estado:** {estado_fase}
""",

        "03_PLAN": """# 03 - PLAN DE IMPLEMENTACIÓN

**Fase:** Planificación
**Expediente:** {expediente}
**Camino:** {camino}

---

## 🎯 OBJETIVO

Crear plan detallado de implementación con tareas, estimaciones y orden de ejecución.

---

## 📥 ENTRADAS

- 00_ESTRATEGIA.md (objetivo)
- 01_ANALISIS.md (requisitos)
- 02_INVESTIGACION.md (decisión técnica) [si aplica]

---

## 📤 SALIDAS

- [ ] Lista de tareas detalladas
- [ ] Estimación de esfuerzo por tarea
- [ ] Orden de ejecución definido
- [ ] Dependencias entre tareas identificadas

---

## ✅ CHECKLIST

- [ ] Todas las tareas listadas (ninguna olvidada)
- [ ] Cada tarea tiene estimación
- [ ] Orden de ejecución lógico
- [ ] Dependencias explícitas
- [ ] Plan de testing incluido

---

## 📝 CONTENIDO

### Tareas

#### 1. [Nombre Tarea]
- **Descripción:** [Qué hacer]
- **Estimación:** [Xh]
- **Depende de:** [Tarea Y]
- **Archivos afectados:** [lista]

#### 2. [Siguiente tarea]
[Similar estructura]

### Orden de Ejecución
1. Tarea X → Tarea Y → Tarea Z
2. ...

### Plan de Testing
- Unit tests: [qué testear]
- Integration tests: [qué testear]
- E2E tests: [qué testear]

---

**Estado:** {estado_fase}
""",

        "04_DISENO": """# 04 - DISEÑO TÉCNICO

**Fase:** Diseño Detallado
**Expediente:** {expediente}
**Camino:** {camino}

---

## 🎯 OBJETIVO

Diseñar la solución técnica completa: arquitectura, estructura de datos, interfaces, flujos.

---

## 📥 ENTRADAS

- 03_PLAN.md (plan de implementación)
- Código existente del sistema

---

## 📤 SALIDAS

- [ ] Diagrama de arquitectura
- [ ] Modelo de datos (si aplica)
- [ ] Interfaces definidas (APIs, funciones)
- [ ] Flujos de ejecución documentados

---

## ✅ CHECKLIST

- [ ] Arquitectura clara y documentada
- [ ] Todos los nombres en DICCIONARIO_DOMINIO.md ⚠️
- [ ] Interfaces públicas definidas
- [ ] Flujos críticos diagramados
- [ ] Validaciones especificadas

---

## 📝 CONTENIDO

### Arquitectura
[Diagrama o descripción de componentes]

### Modelo de Datos
**IMPORTANTE:** Consultar `docs/DICCIONARIO_DOMINIO.md` antes de crear nombres nuevos.

#### Tablas/Entidades
- `nombre_tabla_1` (según diccionario)
  - Campos: [lista]

### Interfaces

#### API/Funciones Públicas
```python
def funcion_principal(param1: tipo) -> tipo:
    \"\"\"Descripción\"\"\"
    pass
```

### Flujos de Ejecución
1. Usuario hace X
2. Sistema valida Y
3. Sistema ejecuta Z
4. Sistema retorna resultado

---

**Estado:** {estado_fase}
""",

        "05_RESULTADO": """# 05 - RESULTADO (IMPLEMENTACIÓN)

**Fase:** Implementación
**Expediente:** {expediente}
**Camino:** {camino}

---

## 🎯 OBJETIVO

Implementar la solución según el diseño, escribiendo código production-ready con tests.

---

## 📥 ENTRADAS

- 03_PLAN.md (tareas)
- 04_DISENO.md (diseño técnico)
- Diccionario de dominio: `docs/DICCIONARIO_DOMINIO.md` ⚠️

---

## 📤 SALIDAS

- [ ] Código implementado (100%)
- [ ] Tests unitarios (cobertura >= 80%)
- [ ] Tests integración (casos críticos)
- [ ] Código revisado (self-review)

---

## ✅ CHECKLIST

- [ ] Todas las tareas del plan completadas
- [ ] Tests escritos y pasando (green)
- [ ] Código cumple convenciones del proyecto
- [ ] Sin código comentado/debug
- [ ] Nombres verificados en diccionario de dominio
- [ ] PROPUESTA_DICCIONARIO.md actualizada (si hay nombres nuevos)

---

## 📝 CONTENIDO

### Implementación Completada

#### Archivos Creados/Modificados
- `src/archivo1.py` - [Descripción cambios]
- `src/archivo2.py` - [Descripción cambios]
- `tests/test_archivo1.py` - [Tests agregados]

### Tests
- **Unitarios:** [X/Y pasando]
- **Integración:** [X/Y pasando]
- **Cobertura:** [%]

### Notas de Implementación
[Decisiones tomadas durante implementación, desviaciones del plan, etc.]

---

**Estado:** {estado_fase}
""",

        "06_VALIDACION": """# 06 - VALIDACIÓN

**Fase:** Validación y QA
**Expediente:** {expediente}
**Camino:** {camino}

---

## 🎯 OBJETIVO

Validar que la implementación cumple todos los requisitos y está lista para despliegue.

---

## 📥 ENTRADAS

- 05_RESULTADO.md (implementación completada)
- 01_ANALISIS.md (requisitos originales)
- 00_ESTRATEGIA.md (criterios de éxito)

---

## 📤 SALIDAS

- [ ] Todos los requisitos verificados
- [ ] Tests E2E ejecutados
- [ ] Performance validada
- [ ] Security scan ejecutado

---

## ✅ CHECKLIST

- [ ] Requisitos funcionales: 100% cumplidos
- [ ] Requisitos no funcionales: validados
- [ ] Tests: 100% pasando
- [ ] Performance: dentro de SLAs
- [ ] Security: sin vulnerabilidades críticas
- [ ] Code review: aprobado

---

## 📝 CONTENIDO

### Validación de Requisitos

#### Requisitos Funcionales
- [RF-1]: ✅ Cumplido
- [RF-2]: ✅ Cumplido

#### Requisitos No Funcionales
- Performance: ✅ P95 < Xms
- Security: ✅ Sin vulnerabilidades
- Escalabilidad: ✅ Soporta Y usuarios

### Tests E2E
```bash
# Ejecutar:
npm run test:e2e

# Resultado:
✅ X/X tests passing
```

### Issues Encontrados
[Lista de issues menores encontrados + resolución]

---

**Estado:** {estado_fase}
""",

        "07_DESPLIEGUE": """# 07 - DESPLIEGUE

**Fase:** Deployment
**Expediente:** {expediente}
**Camino:** {camino}

---

## 🎯 OBJETIVO

Desplegar la solución a producción de forma segura y controlada.

---

## 📥 ENTRADAS

- 06_VALIDACION.md (validación completada)
- Código listo en rama

---

## 📤 SALIDAS

- [ ] Código mergeado a main
- [ ] Desplegado en producción
- [ ] Monitoreo activado
- [ ] Rollback plan listo

---

## ✅ CHECKLIST

- [ ] PR creado y aprobado
- [ ] CI/CD pipeline: green
- [ ] Backup realizado (si aplica)
- [ ] Deployment ejecutado
- [ ] Smoke tests: passing
- [ ] Rollback plan documentado

---

## 📝 CONTENIDO

### Pre-Deployment

#### PR
- **Número:** #XXX
- **Estado:** ✅ Aprobado
- **Reviewers:** [Nombres]

#### CI/CD
```bash
✅ Build: SUCCESS
✅ Tests: PASS
✅ Linter: PASS
```

### Deployment

#### Comando
```bash
# Ejecutado:
just deploy production
```

#### Resultado
- **Fecha:** YYYY-MM-DD HH:MM
- **Versión:** vX.Y.Z
- **Estado:** ✅ SUCCESS

### Post-Deployment

#### Smoke Tests
- [Test 1]: ✅ PASS
- [Test 2]: ✅ PASS

#### Rollback Plan
```bash
# Si algo falla:
just rollback vX.Y.Z-1
```

---

**Estado:** {estado_fase}
""",

        "08_OPERACION": """# 08 - OPERACIÓN

**Fase:** Monitoreo y Soporte
**Expediente:** {expediente}
**Camino:** {camino}

---

## 🎯 OBJETIVO

Monitorear el sistema en producción y dar soporte durante el período de estabilización.

---

## 📥 ENTRADAS

- 07_DESPLIEGUE.md (deployment completado)
- Monitoreo configurado

---

## 📤 SALIDAS

- [ ] Sistema estable (X días sin incidentes)
- [ ] Métricas dentro de rangos
- [ ] Documentación usuario actualizada
- [ ] Incidentes resueltos

---

## ✅ CHECKLIST

- [ ] Monitoreo activo y funcionando
- [ ] Métricas clave en verde
- [ ] 0 incidentes críticos
- [ ] Documentación usuario completa
- [ ] Equipo entrenado (si aplica)

---

## 📝 CONTENIDO

### Monitoreo

#### Métricas Clave
- **Uptime:** 99.X%
- **Response time P95:** Xms
- **Error rate:** 0.X%

#### Alertas Configuradas
- [Alerta 1]: threshold + acción
- [Alerta 2]: threshold + acción

### Incidentes

#### Incidente 1
- **Fecha:** YYYY-MM-DD
- **Severidad:** [Baja/Media/Alta]
- **Descripción:** [Qué pasó]
- **Resolución:** [Cómo se resolvió]

### Documentación Usuario
- [Link a docs actualizadas]

---

**Estado:** {estado_fase}
""",

        "09_EVOLUCION": """# 09 - EVOLUCIÓN

**Fase:** Mejora Continua
**Expediente:** {expediente}
**Camino:** {camino}

---

## 🎯 OBJETIVO

Identificar oportunidades de mejora y planear evolución futura del sistema.

---

## 📥 ENTRADAS

- 08_OPERACION.md (métricas de operación)
- Feedback de usuarios
- Bugs reportados

---

## 📤 SALIDAS

- [ ] Retrospectiva completada
- [ ] Lecciones aprendidas documentadas
- [ ] Mejoras futuras priorizadas
- [ ] Roadmap actualizado

---

## ✅ CHECKLIST

- [ ] Retrospectiva realizada
- [ ] Lecciones aprendidas capturadas
- [ ] Mejoras técnicas identificadas
- [ ] Mejoras funcionales identificadas
- [ ] Próximos pasos definidos

---

## 📝 CONTENIDO

### Retrospectiva

#### ✅ Qué funcionó bien
- [Item 1]
- [Item 2]

#### ❌ Qué mejorar
- [Item 1]
- [Item 2]

#### 💡 Lecciones Aprendidas
1. [Lección 1]
2. [Lección 2]

### Mejoras Futuras

#### Técnicas
- [Mejora técnica 1] - Prioridad: Alta/Media/Baja
- [Mejora técnica 2]

#### Funcionales
- [Mejora funcional 1] - Prioridad: Alta/Media/Baja
- [Mejora funcional 2]

### Próximos Pasos
1. [Acción 1]
2. [Acción 2]

---

**Estado:** {estado_fase}
"""
    }

    def __init__(self, config: ConfiguracionBuzones):
        self.config = config
        self.habilitado = config.get("generacion_fases.habilitado", True)

    def generar(self, carpeta_expediente: Path, fases: List[str], metadatos: Dict):
        """Genera archivos de fases en el expediente"""

        if not self.habilitado:
            return

        for fase in fases:
            self._generar_fase(carpeta_expediente, fase, metadatos)

    def _generar_fase(self, carpeta_expediente: Path, fase: str, metadatos: Dict):
        """Genera un archivo de fase específico"""

        archivo_fase = carpeta_expediente / f"{fase}.md"

        # No sobrescribir si ya existe
        if archivo_fase.exists():
            return

        # Obtener plantilla
        plantilla = self.PLANTILLAS.get(fase, "# {fase}\n\nPlantilla no disponible.")

        # Reemplazar variables
        contenido = plantilla.format(
            expediente=metadatos.get("expediente", ""),
            camino=metadatos.get("camino", ""),
            categoria=metadatos.get("categoria", ""),
            severidad=metadatos.get("severidad", ""),
            urgencia=metadatos.get("urgencia", ""),
            archivo_principal=metadatos.get("archivo_principal", ""),
            estado_fase="NO INICIADO"
        )

        # Escribir archivo
        try:
            with open(archivo_fase, "w", encoding="utf-8") as f:
                f.write(contenido)
            logger.info(f"    Fase generada: {fase}.md")
        except Exception as e:
            logger.error(f"Error al generar fase {fase}: {e}")

# ==============================================================================
# GESTOR DE DICCIONARIO DE DOMINIO (CENTRAL EN docs/)
# ==============================================================================

class GestorDiccionario:
    """Gestiona diccionario central y propuestas de cambios"""

    def __init__(self, config: ConfiguracionBuzones):
        self.config = config
        self.habilitado = config.get("diccionario_dominio.habilitado", True)
        self.ubicacion_central = config.get("diccionario_dominio.ubicacion", "docs/DICCIONARIO_DOMINIO.md")

    def inicializar_diccionario_central(self, raiz_proyecto: Path):
        """Crea diccionario central en docs/ si no existe (solo primera vez)"""

        if not self.habilitado:
            return

        archivo_dict = raiz_proyecto / self.ubicacion_central

        if archivo_dict.exists():
            logger.info("Diccionario central ya existe en docs/")
            return

        # Crear directorio docs/ si no existe
        archivo_dict.parent.mkdir(parents=True, exist_ok=True)

        contenido = f"""# DICCIONARIO DE DOMINIO

**Propósito:** Fuente única de verdad para nombres de tablas, campos, variables, estados y enums del proyecto.

**Ubicación:** Este archivo es ÚNICO y está en `docs/` como parte del sistema Hub and Spoke de documentación.

**Coordinación:** Todos los expedientes deben:
1. **Consultar este archivo** antes de crear nombres nuevos
2. **Proponer cambios** en `PROPUESTA_DICCIONARIO.md` de su expediente
3. **Actualizar este archivo central** una vez aprobado el cambio

---

## 1. Convenciones de Nombres

### Tablas/Entidades
- **snake_case** minúsculas
- Plural para colecciones: `usuarios`, `pedidos`
- Singular para entidades: `configuracion`, `sistema`

### Campos/Atributos
- **snake_case** minúsculas
- Descriptivos y autoexplicativos
- `id` siempre como clave primaria
- Timestamps: `created_at`, `updated_at`, `deleted_at`

### Estados/Enums
- **UPPER_CASE** con guiones bajos
- Descriptivos del estado: `PENDIENTE`, `EN_PROCESO`, `COMPLETADO`
- Agrupados por dominio: `ESTADO_PEDIDO_*`, `ESTADO_USUARIO_*`

### Variables/Funciones (código)
- **camelCase** para JavaScript/TypeScript
- **snake_case** para Python
- Nombres verbos para funciones: `obtenerUsuario()`, `validarEmail()`
- Nombres sustantivos para variables: `usuario`, `totalPedidos`

---

## 2. Tablas/Entidades

*(Agregar aquí las tablas según se vayan definiendo en expedientes)*

### Ejemplo: `usuarios`
- **Descripción:** Almacena información de usuarios del sistema
- **Campos:**
  - `id` (uuid, PK)
  - `email` (varchar(255), unique, not null)
  - `nombre` (varchar(100))
  - `created_at` (timestamp, not null)
  - `updated_at` (timestamp, not null)
- **Índices:**
  - PK en `id`
  - UNIQUE en `email`
- **Relaciones:**
  - `usuarios.id` ← `pedidos.usuario_id` (1:N)

---

## 3. Estados/Enums

*(Agregar aquí los enums según se vayan definiendo)*

### Ejemplo: Estados de Pedido
```python
ESTADO_PEDIDO_PENDIENTE = "PENDIENTE"
ESTADO_PEDIDO_EN_PROCESO = "EN_PROCESO"
ESTADO_PEDIDO_COMPLETADO = "COMPLETADO"
ESTADO_PEDIDO_CANCELADO = "CANCELADO"
```

---

## 4. Validaciones

*(Agregar aquí reglas de validación comunes)*

### Ejemplo: Email
- Formato: RFC 5322 compliant
- Longitud: 5-255 caracteres
- Único en sistema

---

## 5. Glosario de Negocio

*(Términos del dominio de negocio con su significado canónico)*

- **Usuario:** Persona registrada en el sistema con credenciales
- **Pedido:** Solicitud de compra realizada por un usuario
- **[Agregar más términos según proyecto]**

---

## 6. Historial de Cambios

*(Registrar aquí cada cambio al diccionario con fecha y expediente origen)*

- **{datetime.now().strftime("%Y-%m-%d")}:** Diccionario inicial creado por vigilante_v2.3.1.py

---

**Última actualización:** {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
**Mantenido por:** Coordinación entre expedientes
**Consultas:** Antes de crear CUALQUIER nombre nuevo en código/diseño
"""

        try:
            with open(archivo_dict, "w", encoding="utf-8") as f:
                f.write(contenido)
            logger.success(f"✅ Diccionario central creado en {self.ubicacion_central}")
        except Exception as e:
            logger.error(f"Error al crear diccionario central: {e}")

    def generar_propuesta_expediente(self, carpeta_expediente: Path, metadatos: Dict):
        """Genera plantilla PROPUESTA_DICCIONARIO.md en expediente"""

        if not self.habilitado:
            return

        archivo_propuesta = carpeta_expediente / "PROPUESTA_DICCIONARIO.md"

        # No sobrescribir
        if archivo_propuesta.exists():
            return

        expediente = metadatos.get("expediente", "")

        contenido = f"""# PROPUESTA DE CAMBIO AL DICCIONARIO DE DOMINIO

**Expediente:** {expediente}
**Fecha:** {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
**Autor:** Claude / Usuario
**Estado:** PENDIENTE

---

## 📖 INSTRUCCIONES

**REGLA FUNDAMENTAL:** Ningún nombre nuevo de tabla/campo/variable/estado puede aparecer en el código sin estar registrado en el diccionario central primero.

**PROCESO OBLIGATORIO:**

1. **Antes de crear nombres nuevos:**
   - Abrir `docs/DICCIONARIO_DOMINIO.md` (diccionario central)
   - Verificar que el nombre NO existe
   - Documentar aquí el cambio propuesto

2. **Documentar cambio:**
   - Nombre completo (tabla, campo, enum, etc.)
   - Tipo de dato / tipo de cambio
   - Validaciones / restricciones
   - Descripción clara del propósito

3. **Aprobar cambio:**
   - Usuario/arquitecto revisa esta propuesta
   - Usuario actualiza `docs/DICCIONARIO_DOMINIO.md` manualmente
   - Usuario registra en historial de cambios del diccionario
   - Usuario marca este cambio como APROBADO

4. **Solo entonces implementar en código**

---

## 💡 EJEMPLOS

### Ejemplo: Nueva Tabla

**Nombre:** `nombre_tabla`

**Descripción:** [Para qué se usa]

**Campos:**
- `id` (uuid, PK)
- `campo_1` (tipo, restricciones)
- `campo_2` (tipo, restricciones)
- `created_at` (timestamp, not null)
- `updated_at` (timestamp, not null)

**Índices:**
- PK en `id`
- INDEX en `campo_1`

**Relaciones:**
- FK a `tabla_existente.id`

---

### Ejemplo: Nuevo Enum/Estado

**Nombre:** `ENUM_NAME_VALOR`

**Valores:**
- `VALOR_1` - Descripción significado
- `VALOR_2` - Descripción significado
- `VALOR_3` - Descripción significado

**Usado en:** [Tabla X, campo Y]

---

## ✏️ CAMBIOS PROPUESTOS

*(Documentar aquí tus propuestas siguiendo el formato de ejemplos)*

### 1. [Título del cambio]

[Descripción completa]

---

## ✅ APROBACIÓN

- [ ] Validado contra convenciones del proyecto
- [ ] No conflicto con nombres existentes en diccionario
- [ ] Documentado completamente
- [ ] Listo para integrar en `docs/DICCIONARIO_DOMINIO.md`

**Aprobado por:** ____________
**Fecha aprobación:** ____________

---

**Referencia:** `docs/DICCIONARIO_DOMINIO.md` (diccionario central)
"""

        try:
            with open(archivo_propuesta, "w", encoding="utf-8") as f:
                f.write(contenido)
            logger.info(f"    PROPUESTA_DICCIONARIO.md generada")
        except Exception as e:
            logger.error(f"Error al generar propuesta de diccionario: {e}")

# ==============================================================================
# GESTOR DE ESTADO (ESTADO.json)
# ==============================================================================

class GestorEstado:
    """Gestor de archivo ESTADO.json para tracking del expediente"""

    def crear_actualizar(self, carpeta_expediente: Path, metadatos: Dict):
        """Crea o actualiza ESTADO.json"""

        archivo_estado = carpeta_expediente / "ESTADO.json"

        estado = {
            "expediente": metadatos.get("expediente", ""),
            "creado_en": datetime.now().isoformat(),
            "archivo_principal": metadatos.get("archivo_principal", ""),
            "clasificacion": {
                "categoria": metadatos.get("categoria", ""),
                "severidad": metadatos.get("severidad", ""),
                "impacto": metadatos.get("impacto", ""),
                "urgencia": metadatos.get("urgencia", ""),
                "complejidad": metadatos.get("complejidad", "")
            },
            "camino_estrategico": {
                "camino": metadatos.get("camino", ""),
                "justificacion": metadatos.get("justificacion", "")
            },
            "fases_generadas": metadatos.get("fases", []),
            "fase_actual": metadatos.get("fases", [""])[0] if metadatos.get("fases") else "",
            "estado": "ACTIVO",
            "timestamps": {
                "creado": datetime.now().isoformat(),
                "ultima_actualizacion": datetime.now().isoformat()
            }
        }

        try:
            with open(archivo_estado, "w", encoding="utf-8") as f:
                json.dump(estado, f, indent=2, ensure_ascii=False)
            logger.info(f"    ESTADO.json generado/actualizado")
        except Exception as e:
            logger.error(f"Error al crear/actualizar ESTADO.json: {e}")

# ==============================================================================
# GESTOR DE EXPEDIENTES
# ==============================================================================

class GestorExpedientes:
    """Gestiona la creación y manipulación de expedientes"""

    def __init__(self, config: ConfiguracionBuzones):
        self.config = config
        self.dir_entrada = DIR_ENTRADA
        self.dir_taller = DIR_TALLER
        self.clasificador = ClasificadorInteligente(config)
        self.decisor = DecisorCamino()
        self.generador_fases = GeneradorFases(config)
        self.gestor_dict = GestorDiccionario(config)
        self.gestor_estado = GestorEstado()

        # Crear directorios si no existen
        self.dir_entrada.mkdir(parents=True, exist_ok=True)
        self.dir_taller.mkdir(parents=True, exist_ok=True)

        # Inicializar diccionario central (solo primera vez)
        self.gestor_dict.inicializar_diccionario_central(RAIZ)

    def generar_id_expediente(self, nombre_archivo: str) -> str:
        """Genera ID único para expediente"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        nombre_base = Path(nombre_archivo).stem
        # Sanitizar nombre (solo alfanuméricos y guiones)
        nombre_sanitizado = "".join(c if c.isalnum() or c in "-_" else "_" for c in nombre_base)
        return f"{nombre_sanitizado}_{timestamp}"

    def crear_expediente(self, archivo_origen: Path) -> Optional[str]:
        """Crea expediente a partir de archivo en entrada/"""

        try:
            # Verificar que el archivo existe
            if not archivo_origen.exists():
                logger.error(f"Archivo no encontrado: {archivo_origen}")
                return None

            logger.info(f"📄 Procesando: {archivo_origen.name}")

            # Generar ID de expediente
            id_expediente = self.generar_id_expediente(archivo_origen.name)
            carpeta_expediente = self.dir_taller / id_expediente

            # Crear carpeta del expediente
            carpeta_expediente.mkdir(parents=True, exist_ok=True)
            logger.info(f"[NUEVO] Expediente creado: {id_expediente}/")

            # Mover archivo original a carpeta de expediente
            archivo_destino = carpeta_expediente / archivo_origen.name
            shutil.move(str(archivo_origen), str(archivo_destino))
            logger.info(f"    Archivo movido: {archivo_origen.name}")

            # Leer contenido para clasificación
            contenido = self._leer_contenido(archivo_destino)
            extension = archivo_destino.suffix.lower()

            # Clasificación inteligente
            clasificacion = self.clasificador.clasificar(contenido, extension)
            logger.info(f"[INFO] Clasificación: {clasificacion['categoria']} / Complejidad: {clasificacion['complejidad']}")

            # Decisión de camino
            camino, justificacion = self.decisor.decidir(clasificacion)
            logger.info(f"[INFO] Camino asignado: {camino}")
            logger.info(f"    Justificación: {justificacion}")

            # Fases a generar
            fases = self.decisor.obtener_fases(camino)
            logger.info(f"[INFO] Generando {len(fases)} fases: {', '.join(fases)}")

            # Metadatos completos
            metadatos = {
                "expediente": id_expediente,
                "archivo_principal": archivo_destino.name,
                "camino": camino,
                "justificacion": justificacion,
                "fases": fases,
                **clasificacion
            }

            # Generar archivos de fases
            self.generador_fases.generar(carpeta_expediente, fases, metadatos)

            # Generar propuesta de diccionario
            self.gestor_dict.generar_propuesta_expediente(carpeta_expediente, metadatos)

            # Generar ESTADO.json
            self.gestor_estado.crear_actualizar(carpeta_expediente, metadatos)

            # Generar instrucciones para agente (playbook operacional)
            self._generar_instrucciones_playbook(carpeta_expediente, metadatos)

            # Lanzamiento automático de Claude (si habilitado)
            self._lanzar_agente(carpeta_expediente, id_expediente)

            logger.success(f"✅ Expediente completado: {id_expediente}")
            return id_expediente

        except Exception as e:
            logger.error(f"Error al crear expediente: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return None

    def _leer_contenido(self, archivo: Path, max_lineas: int = 120) -> str:
        """Lee contenido del archivo (primeras N líneas)"""
        try:
            with open(archivo, "r", encoding="utf-8", errors="ignore") as f:
                lineas = []
                for i, linea in enumerate(f):
                    if i >= max_lineas:
                        break
                    lineas.append(linea)
                return "".join(lineas)
        except Exception as e:
            logger.warning(f"No se pudo leer contenido: {e}")
            return ""

    def _generar_instrucciones_playbook(self, carpeta_expediente: Path, metadatos: Dict):
        """Genera INSTRUCCIONES_AGENTE.md como playbook operacional completo"""

        fases = metadatos.get("fases", [])
        camino = metadatos.get("camino", "")
        expediente = metadatos.get("expediente", "")

        # Generar lista de fases con estado
        fases_lista = "\n".join([f"- ✅ **{fase}.md** - APLICA (ejecutar en orden)" for fase in fases])

        # Generar playbook detallado de cada fase
        playbook_fases = []
        for fase in fases:
            playbook_fases.append(f"""
### {fase}

**Estado:** APLICA

**Objetivo:** {self._obtener_objetivo_fase(fase)}

**Entradas:**
{self._obtener_entradas_fase(fase)}

**Salidas:**
{self._obtener_salidas_fase(fase)}

**Checklist:**
{self._obtener_checklist_fase(fase)}

**Archivo completo:** `{fase}.md`

---
""")

        playbook_completo = "\n".join(playbook_fases)

        contenido = f"""# INSTRUCCIONES PARA AGENTE (PLAYBOOK OPERACIONAL)

**Expediente:** {expediente}
**Creado:** {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
**Archivo principal:** {metadatos.get('archivo_principal', '')}

---

## 🎯 CLASIFICACIÓN DEL EXPEDIENTE

- **Categoría:** {metadatos.get('categoria', '')}
- **Severidad:** {metadatos.get('severidad', '')}
- **Impacto:** {metadatos.get('impacto', '')}
- **Urgencia:** {metadatos.get('urgencia', '')}
- **Complejidad:** {metadatos.get('complejidad', '')}

---

## 🛤️ CAMINO ESTRATÉGICO ASIGNADO

**Camino:** {camino}

**Justificación:** {metadatos.get('justificacion', '')}

**Fases a ejecutar:** {len(fases)}

---

## 📋 LISTA DE FASES (ORDEN DE EJECUCIÓN)

{fases_lista}

---

## 📖 PLAYBOOK DETALLADO DE CADA FASE

{playbook_completo}

---

## 📚 DICCIONARIO DE DOMINIO (⚠️ OBLIGATORIO)

**Ubicación:** `docs/DICCIONARIO_DOMINIO.md` (raíz del proyecto, ÚNICO)

**REGLA FUNDAMENTAL:**
Ningún nombre nuevo de tabla/campo/variable/estado puede aparecer en el código sin estar registrado en el diccionario central primero.

**PROCESO OBLIGATORIO:**

1. **Abrir:** `docs/DICCIONARIO_DOMINIO.md` (diccionario central del proyecto)
2. **Verificar** si el nombre ya existe
3. **Si NO existe:**
   a. Abrir `PROPUESTA_DICCIONARIO.md` en este expediente
   b. Documentar propuesta de cambio completa
   c. (Opcional) Actualizar `docs/DICCIONARIO_DOMINIO.md` si tienes permiso
   d. Registrar en historial de cambios del diccionario
4. **Solo entonces implementar en código**

**Checklist mínimo:**
- [ ] Consultado `docs/DICCIONARIO_DOMINIO.md` antes de crear nombres
- [ ] Propuesta documentada en `PROPUESTA_DICCIONARIO.md` (si hay nombres nuevos)
- [ ] Diccionario central actualizado (si aprobado)
- [ ] Historial de cambios actualizado

---

## 🎯 PRÓXIMOS PASOS

1. **Revisar clasificación** y validar que el camino asignado es correcto
2. **Ejecutar fases en orden numérico** (empezando por {fases[0] if fases else 'N/A'})
3. **Consultar diccionario** antes de crear cualquier nombre nuevo
4. **Documentar propuestas** en PROPUESTA_DICCIONARIO.md
5. **Al completar todas las fases:** Ejecutar `just concluir {expediente}`

---

## 📝 REGLAS IMPORTANTES

1. **SOLO ejecutar fases marcadas como "APLICA"** (las listadas arriba)
2. **Respetar orden numérico** de fases (no saltarse ninguna)
3. **Consultar docs/DICCIONARIO_DOMINIO.md** ANTES de crear nombres nuevos
4. **Documentar decisiones** en cada archivo de fase
5. **Al terminar una fase:** Marcar checklist completo antes de pasar a la siguiente

---

## 🔄 TRACKING DE ESTADO

**Archivo:** `ESTADO.json`

Este archivo contiene el estado actualizado del expediente (clasificación, camino, fases, timestamps). Consultar/actualizar según progreso.

---

**Sistema:** Fábrica Agéntica v2.3.1
**Generado automáticamente por:** vigilante_v2.3.1.py
**Documentación Hub:** CLAUDE.md (raíz del proyecto)
"""

        # Escribir archivo de instrucciones
        archivo_instrucciones = carpeta_expediente / "INSTRUCCIONES_AGENTE.md"
        try:
            with open(archivo_instrucciones, "w", encoding="utf-8") as f:
                f.write(contenido)
            logger.info(f"    INSTRUCCIONES_AGENTE.md generado (playbook completo)")
        except Exception as e:
            logger.error(f"Error al generar instrucciones: {e}")

    def _obtener_objetivo_fase(self, fase: str) -> str:
        """Retorna objetivo resumido de una fase"""
        objetivos = {
            "00_ESTRATEGIA": "Definir objetivo, alcance y estrategia general",
            "01_ANALISIS": "Analizar requisitos funcionales y no funcionales",
            "02_INVESTIGACION": "Investigar opciones técnicas y decidir enfoque",
            "03_PLAN": "Crear plan detallado de implementación",
            "04_DISENO": "Diseñar arquitectura y modelo de datos",
            "05_RESULTADO": "Implementar código con tests",
            "06_VALIDACION": "Validar requisitos y ejecutar QA",
            "07_DESPLIEGUE": "Desplegar a producción",
            "08_OPERACION": "Monitorear y dar soporte",
            "09_EVOLUCION": "Retrospectiva y mejora continua"
        }
        return objetivos.get(fase, "Ver archivo de fase para detalles")

    def _obtener_entradas_fase(self, fase: str) -> str:
        """Retorna entradas resumidas de una fase"""
        entradas = {
            "00_ESTRATEGIA": "- Archivo principal del expediente\n- Clasificación automática",
            "01_ANALISIS": "- 00_ESTRATEGIA.md\n- Archivo principal",
            "02_INVESTIGACION": "- 01_ANALISIS.md (requisitos)",
            "03_PLAN": "- 00_ESTRATEGIA.md, 01_ANALISIS.md, 02_INVESTIGACION.md",
            "04_DISENO": "- 03_PLAN.md\n- Código existente",
            "05_RESULTADO": "- 03_PLAN.md, 04_DISENO.md\n- docs/DICCIONARIO_DOMINIO.md",
            "06_VALIDACION": "- 05_RESULTADO.md\n- Requisitos originales",
            "07_DESPLIEGUE": "- 06_VALIDACION.md\n- Código en rama",
            "08_OPERACION": "- 07_DESPLIEGUE.md\n- Monitoreo configurado",
            "09_EVOLUCION": "- 08_OPERACION.md\n- Feedback usuarios"
        }
        return entradas.get(fase, "- Ver archivo de fase")

    def _obtener_salidas_fase(self, fase: str) -> str:
        """Retorna salidas resumidas de una fase"""
        salidas = {
            "00_ESTRATEGIA": "- Objetivo claro\n- Criterios de éxito\n- Riesgos identificados",
            "01_ANALISIS": "- AS-IS documentado\n- TO-BE documentado\n- Requisitos completos",
            "02_INVESTIGACION": "- Opciones evaluadas\n- Decisión técnica\n- ADR (si aplica)",
            "03_PLAN": "- Tareas detalladas\n- Estimaciones\n- Orden de ejecución",
            "04_DISENO": "- Arquitectura\n- Modelo de datos\n- Interfaces definidas",
            "05_RESULTADO": "- Código implementado\n- Tests (>= 80% cobertura)\n- Code review",
            "06_VALIDACION": "- Requisitos verificados\n- Tests E2E\n- QA aprobado",
            "07_DESPLIEGUE": "- Código en producción\n- Smoke tests OK\n- Rollback plan",
            "08_OPERACION": "- Sistema estable\n- Métricas en verde\n- 0 incidentes críticos",
            "09_EVOLUCION": "- Retrospectiva\n- Lecciones aprendidas\n- Roadmap actualizado"
        }
        return salidas.get(fase, "- Ver archivo de fase")

    def _obtener_checklist_fase(self, fase: str) -> str:
        """Retorna checklist resumido de una fase"""
        checklists = {
            "00_ESTRATEGIA": "- [ ] Objetivo documentado\n- [ ] Alcance definido\n- [ ] Riesgos evaluados",
            "01_ANALISIS": "- [ ] AS-IS documentado\n- [ ] TO-BE documentado\n- [ ] Requisitos completos",
            "02_INVESTIGACION": "- [ ] 3+ opciones investigadas\n- [ ] Decisión justificada\n- [ ] ADR creado",
            "03_PLAN": "- [ ] Todas las tareas listadas\n- [ ] Estimaciones completas\n- [ ] Plan de testing",
            "04_DISENO": "- [ ] Arquitectura clara\n- [ ] Nombres en diccionario ⚠️\n- [ ] Interfaces definidas",
            "05_RESULTADO": "- [ ] Código completo\n- [ ] Tests >= 80%\n- [ ] Diccionario actualizado",
            "06_VALIDACION": "- [ ] Requisitos 100%\n- [ ] Tests pasando\n- [ ] Performance OK",
            "07_DESPLIEGUE": "- [ ] PR aprobado\n- [ ] Deploy exitoso\n- [ ] Smoke tests OK",
            "08_OPERACION": "- [ ] Monitoreo activo\n- [ ] Métricas OK\n- [ ] 0 incidentes",
            "09_EVOLUCION": "- [ ] Retrospectiva\n- [ ] Lecciones aprendidas\n- [ ] Mejoras priorizadas"
        }
        return checklists.get(fase, "- [ ] Ver archivo de fase")

    def _lanzar_agente(self, carpeta_expediente: Path, id_expediente: str):
        """Lanza Claude automáticamente con el expediente"""

        if not self.config.get("lanzamiento_automatico.habilitado", False):
            logger.info("    Lanzamiento automático deshabilitado (config)")
            return

        try:
            # Crear script PowerShell para lanzar Claude
            script_ps1 = carpeta_expediente / "EJECUTAR_AGENTE.ps1"

            prompt_detallado = (
                f"Lee INSTRUCCIONES_AGENTE.md en este directorio (es tu playbook operacional completo). "
                f"Este archivo contiene: (1) Clasificación del expediente, (2) Camino estratégico asignado, "
                f"(3) Lista de fases a ejecutar, (4) Playbook detallado de cada fase con objetivos, entradas, salidas y checklists. "
                f"IMPORTANTE: (a) Ejecuta SOLO las fases marcadas como 'APLICA', (b) Respeta el orden numérico de fases, "
                f"(c) Consulta docs/DICCIONARIO_DOMINIO.md ANTES de crear nombres nuevos de tablas/campos/estados, "
                f"(d) Al completar todas las fases, el expediente estará listo para: just concluir {id_expediente}"
            )

            contenido_ps1 = f"""# Lanzador de Claude - Expediente {id_expediente}
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Expediente: {id_expediente}" -ForegroundColor Yellow
Write-Host "  Lanzando Claude con playbook operacional..." -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

cd "{carpeta_expediente}"
claude --dangerously-skip-permissions "{prompt_detallado}"
"""

            with open(script_ps1, "w", encoding="utf-8") as f:
                f.write(contenido_ps1)

            logger.info(f"    EJECUTAR_AGENTE.ps1 generado")

            # Crear script batch (wrapper)
            script_bat = carpeta_expediente / "EJECUTAR_AGENTE.bat"
            contenido_bat = f"""@echo off
powershell.exe -ExecutionPolicy Bypass -File "{script_ps1}"
"""

            with open(script_bat, "w", encoding="utf-8") as f:
                f.write(contenido_bat)

            logger.info(f"    EJECUTAR_AGENTE.bat generado")

            # Intentar ejecutar (abrir nueva ventana de terminal)
            try:
                subprocess.Popen(
                    ["start", "cmd", "/k", str(script_bat)],
                    shell=True,
                    cwd=str(carpeta_expediente)
                )
                logger.success(f"    🤖 Claude lanzado automáticamente")
            except Exception as e:
                logger.warning(f"No se pudo auto-lanzar Claude: {e}")
                logger.info(f"    Ejecutar manualmente: {script_bat}")

        except Exception as e:
            logger.error(f"Error al preparar lanzamiento: {e}")

# ==============================================================================
# PROCESADOR DE ENTRADA (MODO BATCH)
# ==============================================================================

class ProcesadorBatch:
    """Procesa todos los archivos en entrada/ una vez"""

    def __init__(self, config: ConfiguracionBuzones):
        self.config = config
        self.gestor = GestorExpedientes(config)

    def procesar(self):
        """Procesar todos los archivos en entrada/"""
        logger.info("=" * 80)
        logger.info("Iniciando procesamiento BATCH - Fábrica Agéntica v2.3.1")
        logger.info("=" * 80)

        # Listar archivos en entrada/
        archivos = list(DIR_ENTRADA.glob("*"))
        archivos = [f for f in archivos if f.is_file()]

        # Filtrar archivos a ignorar
        archivos_validos = []
        for archivo in archivos:
            if self.config.debe_ignorar(archivo.name):
                logger.info(f"⏭️  Ignorando: {archivo.name}")
            else:
                archivos_validos.append(archivo)

        if not archivos_validos:
            logger.info("📭 No hay archivos para procesar en entrada/")
            return

        logger.info(f"📥 Archivos a procesar: {len(archivos_validos)}")
        logger.info("")

        # Procesar cada archivo
        expedientes_creados = []
        for archivo in archivos_validos:
            id_expediente = self.gestor.crear_expediente(archivo)
            if id_expediente:
                expedientes_creados.append(id_expediente)
            logger.info("")  # Línea en blanco entre expedientes

        # Resumen
        logger.info("=" * 80)
        logger.success(f"✅ Procesamiento completado: {len(expedientes_creados)} expedientes creados")
        logger.info("=" * 80)

        for exp_id in expedientes_creados:
            logger.info(f"  - {exp_id}/")

        logger.info("")
        logger.info("💡 Próximos pasos:")
        logger.info("   1. Claude debería haberse abierto automáticamente con cada expediente")
        logger.info("   2. Si no, revisar expedientes en: fabrica/buzon_agente/taller_activo/")
        logger.info("   3. Ejecutar manualmente: EJECUTAR_AGENTE.bat en cada expediente")
        logger.info("   4. Al terminar expediente: just concluir [id_expediente]")

# ==============================================================================
# MONITOR DE ENTRADA (MODO WATCH)
# ==============================================================================

class EventHandlerEntrada(FileSystemEventHandler):
    """Handler de eventos de watchdog"""

    def __init__(self, config: ConfiguracionBuzones, gestor: GestorExpedientes):
        super().__init__()
        self.config = config
        self.gestor = gestor

    def on_created(self, event):
        """Archivo creado en entrada/"""
        if event.is_directory:
            return

        archivo = Path(event.src_path)

        # Ignorar archivos temporales
        if self.config.debe_ignorar(archivo.name):
            logger.info(f"⏭️  Ignorando: {archivo.name}")
            return

        # Esperar a que el archivo esté completamente escrito
        time.sleep(0.5)

        logger.info(f"🔔 Nuevo archivo detectado: {archivo.name}")
        logger.info("")
        self.gestor.crear_expediente(archivo)
        logger.info("")

class MonitorWatch:
    """Monitor continuo de entrada/ con watchdog"""

    def __init__(self, config: ConfiguracionBuzones):
        if not WATCHDOG_AVAILABLE:
            logger.error("❌ Modo watch requiere watchdog: pip install watchdog")
            sys.exit(1)

        self.config = config
        self.gestor = GestorExpedientes(config)

    def iniciar(self):
        """Iniciar monitoreo continuo"""
        logger.info("=" * 80)
        logger.info("Iniciando VIGILANTE en modo WATCH - Fábrica Agéntica v2.3.1")
        logger.info("=" * 80)
        logger.info(f"📂 Monitoreando: {DIR_ENTRADA}")
        logger.info("👁️  El vigilante está atento...")
        logger.info("⏹️  Presiona Ctrl+C para detener")
        logger.info("")

        event_handler = EventHandlerEntrada(self.config, self.gestor)
        observer = Observer()
        observer.schedule(event_handler, str(DIR_ENTRADA), recursive=False)
        observer.start()

        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            logger.info("")
            logger.info("⏹️  Deteniendo vigilante...")
            observer.stop()

        observer.join()
        logger.info("✅ Vigilante detenido")

# ==============================================================================
# CLI PRINCIPAL
# ==============================================================================

def main():
    """Función principal"""
    parser = argparse.ArgumentParser(
        description="Vigilante de Buzones v2.3.1 - Playbook Operacional Automático"
    )
    parser.add_argument(
        "--modo",
        choices=["batch", "watch"],
        default="batch",
        help="Modo de ejecución: batch (una vez) o watch (continuo)"
    )

    args = parser.parse_args()

    # Cargar configuración
    config = ConfiguracionBuzones(CONFIG_FILE)

    # Verificar que vigilante esté habilitado
    if not config.config.get("vigilante", {}).get("habilitado", True):
        logger.warning("⚠️  Vigilante deshabilitado en configuración")
        return

    # Ejecutar según modo
    if args.modo == "batch":
        procesador = ProcesadorBatch(config)
        procesador.procesar()
    else:  # watch
        monitor = MonitorWatch(config)
        monitor.iniciar()

if __name__ == "__main__":
    main()
